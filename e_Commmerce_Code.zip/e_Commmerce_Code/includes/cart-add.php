<?php
require "common.php";
$id=$_SESSION['id'];
$item_id=$_GET['id'];
$insert_query="INSERT INTO users_items(user_id, items_id, status) VALUES('$id', '$item_id', 'Added to cart')"; 
$insert_query_result=mysqli_query($con, $insert_query) or die(mysqli_error($con));

header('location: ../products.php');

?>