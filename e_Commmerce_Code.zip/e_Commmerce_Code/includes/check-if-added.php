<?php 

function check_if_added_to_cart($con,$item_id){
	$user_id=$_SESSION['id'];
	$select_query="SELECT * FROM users_items WHERE items_id='$item_id' AND user_id ='$user_id' and status='Added to cart' ";
	$select_result=mysqli_query($con, $select_query) or die(mysqli_error($con));
	$total_row_fetched=mysqli_num_rows($select_result);
	
		if($total_row_fetched >=1){
		return 1;}
		else
			return 0;
}
?>	