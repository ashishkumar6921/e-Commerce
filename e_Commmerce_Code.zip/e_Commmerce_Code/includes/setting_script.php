<?php
require "common.php";
if(!isset($_SESSION['id'])){
	header('location:index.php');
	exit;
	}
	$o_password = mysqli_real_escape_string($con, $_POST['password']);
	$n_password = mysqli_real_escape_string($con, $_POST['password1']);
	$r_password = mysqli_real_escape_string($con, $_POST['password2']);
	$hash=md5($o_password);
	$hash1=md5($n_password);
	$hash2=md5($r_password);
	$id=$_SESSION['id'];
	$email=$_SESSION['email_id'];
	echo "$id - $email"; 
$select_query="select password from users where password='".$hash."'and id=".$id." ";
$select_query_result=mysqli_query($con, $select_query) or die(mysqli_error($con));
$total_row_fetched=mysqli_num_rows($select_query_result);
if($total_row_fetched==1 and $hash1==$hash2)
{
    $update_query="update users set password='".$hash1."' where id=".$id." ";
	$update_query_submit=mysqli_query($con, $update_query) or die(mysqli_error($con));
	//echo "Success";
	header('location:../products.php');
	}
else
	{
		header('location:../settings.php?error=');
		//echo "Failed";
		}
	

		
		?>