<?php

$con = mysqli_connect("localhost", "id5482839_database_lifestore", "Database@1234", "id5482839_ecommerce_lifestore") or die(mysqli_error($con));
session_start();
?>