<?php
require "common.php";
$id=$_SESSION['id'];
$item_id=$_GET['id'];
$delete_query="DELETE from users_items where user_id='$id' and items_id='$item_id' ";
$delete_query_result=mysqli_query($con, $delete_query) or die(mysqli_error($con));
header('location: ../cart.php');
?>
