  
  <?php           
  if (isset($_SESSION['id'])) {         
  ?>                  
  <li><a href = "cart.php"><span class = "glyphicon glyphicon-shoppingcart"></span> Cart </a></li>   
  <li><a href = "settings.php"><span class = "glyphicon glyphicon-user"></span> Settings</a></li>       
  <li><a href = "logout.php"><span class = "glyphicon glyphicon-login"></span> Logout</a></li>           
                     
  <?php 

 
                } 
				else 
				{      
				?>      
				<li><a href="signup.php"><span class="glyphicon glyphicon-user"></span> Sign Up</a></li>         
				<li><a href="login.php"><span class="glyphicon glyphicon-log-in"></span> Login</a></li>        
				<?php            
				}              
				?>          
				