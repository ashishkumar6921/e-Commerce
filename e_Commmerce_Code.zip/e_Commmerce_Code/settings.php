<?php
require "includes/common.php";
if(!isset($_SESSION['id'])){
	header('location:index.php');
	exit;
}
?>


<html>
    <head>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" >

        <!--jQuery library--> 
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>

        <!--Latest compiled and minified JavaScript--> 
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
       
        
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Setting</title>
         <link rel="stylesheet" href="style.css" type="text/css"/>
    </head>
    <body>
	
		<?php
		$error='Change Your Password';
		if(isset($_GET['error'])&&empty($_GET['error']))
		    $error="<span style='color:red;'>Password doesn't match!</span>";
		?>
			<div id="content">
        <div class="container-fluid decor_bg" id="login-panel"> 
            <div class="row">
                <div class="col-xs-4 col-xs-offset-4"> 
                    <div class="panel panel-primary" >
                        <div class="panel-heading">
                            <h4>Password Setting</h4>
                        </div>
                        <div class="panel-body">
                            <p class="text-warning"><i><?php echo $error; ?></i></p>
                            <form role="form" action="includes/setting_script.php" method="post">
                                <div class="form-group">
                                    <input type="password" class="form-control"  placeholder="Old Password" name="password" required = "true" >
									<div> </div>
                                </div>
                                <div class="form-group">
                                    <input type="password" class="form-control" placeholder="New Password" name="password1" required = "true" >
									<div> </div>
                                </div>
								<div class="form-group">
                                    <input type="password" class="form-control" placeholder="Re-type new Password" name="password2" required = "true" >
									<div> </div>
                                </div>
                                <button type="submit" name="submit" class="btn btn-primary">submit</button><br><br>
                            </form><br/>
                        </div>
                        
                    </div>
               </div>
            </div>
         </div> 
        </div>
		
		</body></html>