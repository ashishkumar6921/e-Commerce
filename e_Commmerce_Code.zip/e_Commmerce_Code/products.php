<?php
require "includes/common.php";
?>

<!DOCTYPE html>
<html>
    <head>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" >

        <!--jQuery library--> 
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>

        <!--Latest compiled and minified JavaScript--> 
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
       
        
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Products | Life Style Store</title>
         <link rel="stylesheet" href="style.css" type="text/css"/> 
    </head>
    <body>
      <nav class="navbar navbar-inverse navbar-fixed-top" >
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="index.html">Lifestyle Store</a>
                </div>
                <div class="collapse navbar-collapse" id="myNavbar">
                    <ul class="nav navbar-nav navbar-right">
                        
                    
                
					<?php
					include 'includes/header.php';
					include 'includes/check-if-added.php';
					$result=mysqli_query($con,'select * from items ');
					
					
					?>
               </ul>
			</div>
                 </div>
                    </nav>  
        <div class="container " id="content" >
            <div class="jumbotron home-spacer" id="products-jumbotron" >
                <h1>Welcome to our Lifestyle Store!</h1>
                <p>We have the best Cameras, Watches and Shirts for you. No need to hunt around, We have all in one place.</p>
            </div>
            <hr>
            <div class="row text-center " id="cameras" >
                
			<?php
             
			 function check($a,$id)
			 {
				 
			  
			 if (!isset($_SESSION['email_id']))
			 {
				 return "<a href='login.php' role='button' class='btn btn-primary btn-block'>Buy Now</a>"; 
			 }
			 else
			 {
				 if(check_if_added_to_cart($a,$id))
			     {
				    return "<a href='#' class='btn btn-block btn-success' disabled>Added to cart</a>"; 
				 }
				 else
				 {
					 return "<a href='includes/cart-add.php?id=".$id."' name='add' value='add' class='btn btn-block btn-primary'>Add to cart</a>"; 
				}
			 }
			 
			 }
			 
			 
			 if(mysqli_num_rows($result)> 0){
			 while($row=mysqli_fetch_assoc($result))
		     {
				 echo "<div class='col-md-3 col-sm-6 home-feature'>
				        <div class='thumbnail'>
                          <img src='img/".$row['pid'].".jpg' alt=''>
                            <div class='caption'>
                                <h3>".$row['name']."</h3>
                              <p>Price Rs. ".$row['price']."</p>".check($con,$row['pid'])."</div></div></div>";
			 }
			 }
			
			     ?>
				</div>
                
             </div>
          
            <hr>    
                 
       <!-- <footer>
            <div class="container">
                <center>
                    <p>Copyright &copy; Lifestyle Store. All Rights Reserved | Contact Us: +91 90000 00000</p>
                </center>
            </div>
        </footer> -->
		<?php
		include 'includes/footer.php'
		?>
        
    </body>
    </html>