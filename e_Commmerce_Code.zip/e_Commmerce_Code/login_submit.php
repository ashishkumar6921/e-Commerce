<?php

require "includes/common.php";
$email =mysqli_real_escape_string($con, $_POST['email-id']);
 
$regex_email = "/^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,3})$/";

if (!preg_match($regex_email, $email)) {
  header('location: login.php?email_error=enter+correct+email&password_error=');
   
}


$password = mysqli_real_escape_string($con, $_POST['password']);

if (strlen($password) < 6) {
  header('location: login.php?email_error=&password_error=enter%correct%password');
}
$hash=md5($password);
$select_query="select id,email_id from users where email_id='".$email."' and password='".$hash."' ";
$select_query_result=mysqli_query($con, $select_query) or die(mysqli_error($con));
$total_row_fetched=mysqli_num_rows($select_query_result);

if($total_row_fetched==1)
{
	$id=mysqli_fetch_assoc($select_query_result) ;
	$_SESSION['email_id'] = $email;
	$_SESSION['id'] = $id['id'];
		header('location: products.php');
	}
else
	{
		header('location: login.php?error=');
		}
?>