<?php
require "includes/common.php";
if (!isset($_SESSION['id'])){
	header('location:index.php');
	exit;
}
?>
<!--DOCTYPE html-->
<html>
    <head>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" >

        <!--jQuery library--> 
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>

        <!--Latest compiled and minified JavaScript--> 
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
       
        
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>cart page</title>
         <link rel="stylesheet" href="style.css" type="text/css"/> 
    </head>
    <body>
        <div class="container-fluid" id="content">
       <nav class="navbar navbar-inverse navbar-fixed-top" >
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="index.php">Lifestyle Store</a>
                </div>
                <div class="collapse navbar-collapse" id="myNavbar">
                    <ul class="nav navbar-nav navbar-right">
                        <li><a href="cart.php"><span class="glyphicon glyphicon-shopping-cart"></span> Cart</a></li>
                        <li><a href="settings.php"><span class="glyphicon glyphicon-cog"></span>Setting</a></li>
                        <li><a href="logout.php"><span class="glyphicon glyphicon-log-out"></span>Logout</a></li>
                    </ul>
                </div>
                
                    
                </div>
              </nav> 
			  
		
        
            <div class="row decor_bg"> 
                <div class="col-md-6 col-md-offset-3">
				
				<?php
					
					$select="select * from users_items INNER JOIN items ON users_items.items_id=items.pid where users_items.user_id=".$_SESSION['id'];
					$result=mysqli_query($con,$select);
					$total=mysqli_num_rows($result);
					if($total==0){
						?>
						 <div class="jumbotron">
            <h3 align="center"> Add items to the cart first!.</h3><hr>
            <p align="center">Click<a href="products.php"> here</a>  to purchase items.</p>
			</div>
				<?php		
					}
					else
					{
						
						
				?>
        
            <table class="table table-striped table-bordered">
                <thead>
                    <tr>
                         <th>Item Number</th>
                                <th>Item Name</th>
                                <th>Price</th>
                                <th>Action</th>
                    </tr>
                </thead>
                <tbody>
				<?php
				$sum=0;
				while($row=mysqli_fetch_assoc($result))
			    {
					echo "<tr><td>".$row['pid']."</td><td>".$row['name']."</td><td>Rs. ".$row['price']."</td><td> 
					      <a href='includes/cart-remove.php?id=".$row['pid']."' class='remove_item_link'> Remove</a></td> </tr>";	
					$sum+=$row['price'];
				}
				
						
				
                    
                    echo "<tr><td></td><td>Total: ".$total."</td><td>Rs: ".$sum."</td><td><a href='success.php' class='btn btn-primary'>Confirm Order</a>
					      </td></tr></tbody></table>";
					}
					?>
					
                </div>
            </div>
        </div>
      
        
        <!--   <footer>
            <div class="container">
                <center>
                    <p>Copyright &copy; Lifestyle Store. All Rights Reserved | Contact Us: +91 90000 00000</p>
                </center>
            </div>
        </footer>  -->
		<?php
			include 'includes/footer.php';
			?>
        
    </body>
    </html>